//importing
import imgGallery from "./modules/imgGallery.js";

$(document).ready(function () {
  imgGallery();
});
